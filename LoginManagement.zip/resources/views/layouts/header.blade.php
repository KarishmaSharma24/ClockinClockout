<header class="topbar" data-navbarbg="skin5">
  <nav class="navbar top-navbar navbar-expand-md navbar-dark">
    <div class="navbar-header" data-logobg="skin5">

      <a class="navbar-brand" href="index.html">
        <span class="logo-text ms-2">
          <h4>Login Management</h4>
        </span>
      </a>

      <a class="nav-toggler waves-effect waves-light d-block d-md-none"
        href="javascript:void(0)"><i class="ti-menu ti-close"></i>
      </a>
    </div>

    <div
      class="navbar-collapse collapse"
      id="navbarSupportedContent"
      data-navbarbg="skin5">

      <ul class="navbar-nav float-start me-auto">
        <li class="nav-item d-none d-lg-block">
          <a
            class="nav-link sidebartoggler waves-effect waves-light"
            href="javascript:void(0)"
            data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a>
        </li>
        
        <!-- <div class="d-flex ms-auto">
          <button class="btn btn-primary">ClockIn</button>
        </div> -->
      </ul>

    </div>
  </nav>
</header>