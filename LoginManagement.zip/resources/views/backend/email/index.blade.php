<!DOCTYPE html>

<html>

<head>

    <title>Test Email</title>

</head>

<body>

    <h1>Hello!</h1>

    <p>This is a Welcome email from Login Management.</p>

</body>

</html>