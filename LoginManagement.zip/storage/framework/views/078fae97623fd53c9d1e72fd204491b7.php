

<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb">
      <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                  <h4 class="page-title">Staff</h4>
                  <div class="ms-auto text-end">
                        <nav aria-label="breadcrumb">
                              <button type="button" class="btn btn-primary">
                                    <a href="<?php echo e(route('staff.create')); ?>" class="text-light">Create</a>
                              </button>

                        </nav>
                  </div>
            </div>
      </div>
</div>
<div class="container-fluid">
      <div class="row">
            <div class="col-md-12">
                  <div class="card">
                        <form class="form-horizontal">
                              <div class="card-body">
                                    <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success">
                                          <?php echo e(Session::get('success')); ?>

                                          <?php
                                          Session::forget('success');
                                          ?>
                                    </div>
                                    <?php endif; ?>

                                    <table class="table">
                                          <thead>
                                                <tr>
                                                      <th scope="col">S.No.</th>
                                                      <th scope="col">First Name</th>
                                                      <th scope="col">Last Name</th>
                                                      <th scope="col">Email</th>
                                                      <th scope="col">Profile</th>
                                                      <th scope="col">Action</th>
                                                </tr>
                                          </thead>
                                          <tbody>
                                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                      <th scope="row"><?php echo e(++$key); ?></th>
                                                      <td><?php echo e($data->name); ?></td>
                                                      <td><?php echo e($data->name); ?></td>
                                                      <td><?php echo e($data->email); ?></td>
                                                      <?php if($data->image): ?>
                                                      <td><img src="<?php echo e(asset('assets/uploads/images/'.$data->image)); ?>" alt="image" height="50" width="50" /></td>
                                                      <?php else: ?>
                                                      <td>-----</td>
                                                      <?php endif; ?>
                                                      <td>
                                                            <form action="<?php echo e(route('staff.destroy',$data->id)); ?>" method="POST">

                                                                  <!-- <a class="btn btn-info" href="<?php echo e(route('staff.show',$data->id)); ?>">Show</a> -->

                                                                  <a class="btn btn-primary" href="<?php echo e(route('staff.edit',$data->id)); ?>">Edit</a>

                                                                  <?php echo csrf_field(); ?>
                                                                  <?php echo method_field('DELETE'); ?>

                                                                  <button type="submit" class="btn btn-danger">Delete</button>
                                                            </form>
                                                      </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>
                                    </table>
                              </div>

                        </form>
                  </div>

            </div>

      </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Interview\ClockIN-ClockOut\resources\views/backend/staff/index.blade.php ENDPATH**/ ?>