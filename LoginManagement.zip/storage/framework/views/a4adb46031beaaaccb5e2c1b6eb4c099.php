<footer class="footer text-center">
          All Rights Reserved by Matrix-admin. Designed and Developed by
          <!-- <a href="https://www.wrappixel.com">WrapPixel</a>. -->
        </footer><?php /**PATH D:\Interview\ClockIN-ClockOut\resources\views/layouts/footer.blade.php ENDPATH**/ ?>