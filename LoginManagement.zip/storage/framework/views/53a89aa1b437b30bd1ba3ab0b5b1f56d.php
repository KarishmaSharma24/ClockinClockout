<!DOCTYPE html>

<html>

<head>

    <title>Test Email</title>

</head>

<body>

    <h1>Hello!</h1>

    <p>This is a Welcome email from Login Management.</p>

</body>

</html><?php /**PATH D:\Interview\ClockIN-ClockOut\resources\views/backend/email/index.blade.php ENDPATH**/ ?>